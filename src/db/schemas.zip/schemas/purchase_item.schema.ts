import { pgTable, uuid, timestamp, index } from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";

import { purchase } from "./purchase.schema";
import { product } from "./product.schema";
import { createInsertSchema } from "drizzle-zod";
import z from "zod";

// TABLE
export const purchaseItem = pgTable(
	"purchase_item",
	{
		id: uuid("id").defaultRandom().primaryKey(),

		purchaseId: uuid("purchase_id")
			.notNull()
			.references(() => purchase.id, {
				onDelete: "cascade",
			}),

		productId: uuid("product_id")
			.notNull()
			.unique()
			.references(() => product.id, {
				onDelete: "restrict",
			}),

		createdAt: timestamp("created_at", {
			withTimezone: true,
		})
			.notNull()
			.defaultNow(),
	},
	(table) => [index().on(table.purchaseId)],
);

// types
export const purchaseItemsInsertSchema = createInsertSchema(purchaseItem);
export type PurchaseItemsInsertSchemaType = z.infer<
	typeof purchaseItemsInsertSchema
>;

// relations
export const purchaseItemsRelations = relations(purchaseItem, ({ one }) => ({
	purchase: one(purchase, {
		fields: [purchaseItem.purchaseId],
		references: [purchase.id],
	}),

	product: one(product, {
		fields: [purchaseItem.productId],
		references: [product.id],
	}),
}));
