import { pgTable, uuid, varchar } from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";
import { productType } from "./product_type.schema";
import { timestamps } from "../utils/column.helper";

// TABLE
export const itemCodeMapping = pgTable("item_code_mapping", {
	id: uuid("id").defaultRandom().primaryKey(),

	itemCode: varchar("item_code", { length: 100 }).notNull().unique(),

	productTypeId: uuid("product_type_id")
		.notNull()
		.references(() => productType.id, { onDelete: "cascade" }),

	...timestamps,
});

export const itemCodeMappingRelations = relations(
	itemCodeMapping,
	({ one }) => ({
		productType: one(productType, {
			fields: [itemCodeMapping.productTypeId],
			references: [productType.id],
		}),
	}),
);
