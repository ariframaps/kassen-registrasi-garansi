import { pgTable, uuid, varchar, text } from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";
import { timestamps } from "../utils/column.helper";
import { productType } from "./product_type.schema";

// TABLE
export const productCategory = pgTable("product_category", {
	id: uuid("id").defaultRandom().primaryKey(),

	name: varchar("name", { length: 255 }).notNull().unique(),

	...timestamps,
});

export const productCategoryRelations = relations(
	productCategory,
	({ many }) => ({
		productTypes: many(productType),
	}),
);
