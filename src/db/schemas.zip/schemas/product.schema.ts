import {
	pgTable,
	uuid,
	varchar,
	date,
	pgEnum,
	index,
} from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";

import { productType } from "./product_type.schema";
import { deliveryOrders } from "./delivery_order.schema";
import { dealers } from "./dealer.schema";
import { timestamps } from "../utils/column.helper";
import { purchaseItem } from "./purchase_item.schema";
import { warrantyCondition } from "./warranty_condition.schema";
import { z } from "zod";

// ENUM
export const productStatusEnum = pgEnum("product_status", [
	"unassigned",
	"assigned",
	"warranty_active",
	"warranty_expired",
]);

// TABLE
export const product = pgTable(
	"product",
	{
		id: uuid("id").defaultRandom().primaryKey(),

		serialNumber: varchar("serial_number", { length: 100 }).notNull().unique(),

		productTypeId: uuid("product_type_id")
			.notNull()
			.references(() => productType.id, {
				onDelete: "restrict",
			}),

		deliveryOrderId: uuid("delivery_order_id")
			.notNull()
			.references(() => deliveryOrders.id, {
				onDelete: "restrict",
			}),

		dealerId: uuid("dealer_id").references(() => dealers.id, {
			onDelete: "set null",
		}),

		status: productStatusEnum("status").notNull().default("unassigned"),

		warrantyStartDate: date("warranty_start_date"),

		warrantyEndDate: date("warranty_end_date"),

		...timestamps,
	},
	(table) => [
		index().on(table.dealerId),

		index().on(table.productTypeId),

		index().on(table.deliveryOrderId),
	],
);

// schema
export const productInsertSchema = createInsertSchema(product).pick({
	id: true,
	serialNumber: true,
	productTypeId: true,
	deliveryOrderId: true,
	dealerId: true,
	status: true,
	warrantyStartDate: true,
	warrantyEndDate: true,
});
export type ProductInsertSchemaType = z.infer<typeof productInsertSchema>;

// relations
export const productsRelations = relations(product, ({ one, many }) => ({
	productType: one(productType, {
		fields: [product.productTypeId],
		references: [productType.id],
	}),

	deliveryOrder: one(deliveryOrders, {
		fields: [product.deliveryOrderId],
		references: [deliveryOrders.id],
	}),

	dealer: one(dealers, {
		fields: [product.dealerId],
		references: [dealers.id],
	}),

	purchaseItem: one(purchaseItem),

	warrantyCondition: one(warrantyCondition),
}));
