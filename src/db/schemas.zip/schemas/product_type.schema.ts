import {
	pgTable,
	uuid,
	varchar,
	text,
	integer,
	unique,
} from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";
import { productCategory } from "./product_category.schema";
import { timestamps } from "../utils/column.helper";
import { itemCodeMapping } from "./item_code_mapping.schema";
import { product } from "./product.schema";

// TABLE
export const productType = pgTable(
	"product_type",
	{
		id: uuid("id").defaultRandom().primaryKey(),

		categoryId: uuid("category_id")
			.notNull()
			.references(() => productCategory.id, { onDelete: "restrict" }),

		name: varchar("name", { length: 255 }).notNull().unique(),

		warrantyDurationMonths: integer("warranty_duration_months")
			.notNull()
			.default(12),

		...timestamps,
	},
	(table) => [unique().on(table.categoryId, table.name)],
);

export const productTypesRelations = relations(
	productType,
	({ one, many }) => ({
		category: one(productCategory, {
			fields: [productType.categoryId],
			references: [productCategory.id],
		}),

		products: many(product),

		itemCodeMappings: many(itemCodeMapping),
	}),
);
