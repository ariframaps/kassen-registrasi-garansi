import { pgTable, uuid, varchar, text } from "drizzle-orm/pg-core";

import { relations } from "drizzle-orm";
import { timestamps } from "../utils/column.helper";

import { purchase } from "./purchase.schema";

// TABLE
export const customer = pgTable("customer", {
	id: uuid("id").defaultRandom().primaryKey(),

	name: varchar("name", { length: 255 }).notNull(),

	email: varchar("email", { length: 255 }).notNull().unique(),

	phone: varchar("phone", { length: 50 }),

	address: text("address"),

	...timestamps,
});

export const customersRelations = relations(customer, ({ many }) => ({
	purchases: many(purchase),
}));
